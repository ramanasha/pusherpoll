module.exports = {
  mongoURI: '',
  pusherAppId: '',
  pusherKey: '',
  pusherSecret: '',
  pusherCluster: '',
  pusherEncrypted: true
};
